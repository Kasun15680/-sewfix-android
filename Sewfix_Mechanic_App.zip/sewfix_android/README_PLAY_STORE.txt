SEWFIX - PLAY STORE STARTER PROJECT

Package ID: com.sewfix.app
Target SDK: 36 (Android 16 requirement)
Version: 1.0.0 / versionCode 1

WHAT IS INCLUDED
- Android Studio project
- Current Sewfix MVP web app embedded in Android
- Customer login/signup demo
- Machine/problem selection
- Photo/video picker
- Mechanic selection
- WhatsApp contact flow
- Request history/status demo
- Mechanic/Admin demo dashboards

IMPORTANT BEFORE PUBLIC RELEASE
1. Replace demo mechanic WhatsApp numbers with real numbers.
2. Add a real backend/database for production accounts and requests.
3. Create and publish a truthful privacy policy URL.
4. Complete Google Play Data Safety form.
5. Create a signed Android App Bundle (.aab).
6. New personal Play developer accounts may require 12 closed-testers for 14 continuous days before production access.

BUILD
Open this folder in Android Studio. Let Android Studio download the Android SDK/Gradle components. Then use Build > Generate Signed Bundle / APK > Android App Bundle.
Use target/compile SDK 36.

DO NOT SHARE YOUR KEYSTORE OR PASSWORD.
