Sewfix Mechanic App

Demo login: mechanic / 1234

This is a prototype. Repair requests are stored locally for demo/testing.
A real backend will be connected later for customer-to-mechanic real-time requests,
secure authentication, location matching, notifications, and owner-controlled commission balances.

Build with GitHub Actions using Gradle 8.13 and JDK 17.
